ArtaeumGroupTool = {}
local AD = ArtaeumGroupTool

-- Written by M0R_Gaming

AD.name = "ArtaeumGroupTool"
AD.varversion = 1

AD.Settings = {}
AD.Settings.DefaultSettings = {
	SOC = {
		offCrownTimer = 600,
		radius = 25500,
		whitelistGuild = 341929,
	},
	Discord = {
		discordLink = "[Insert Discord Link Here]",
		discordInvite = "Come join us in discord! Even if you don't have a mic, it still helps us coordinate attacks! Come join us at",
	},
	FD = {
		rightClickMenu = true
	},
}

-- The following was adapted from https://wiki.esoui.com/Circonians_Stamina_Bar_Tutorial#lua_Structure




--[[ -- New multigroup sharing

function AD.guildnoteTest(event, guildID, displayName, note)
	d("Incoming guild note from "..displayName.." in guild "..guildID..": "..note)
	d(os.time())
end

EVENT_MANAGER:RegisterForEvent("GUILD NOTE TEST AD", EVENT_GUILD_MEMBER_NOTE_CHANGED, AD.guildnoteTest)

]]--


-------------------------------------------------------------------------------------------------
--  OnAddOnLoaded  --
-------------------------------------------------------------------------------------------------
function AD.OnAddOnLoaded(event, addonName)
	if addonName ~= AD.name then return end

	AD:Initialize()
end
 
-------------------------------------------------------------------------------------------------
--  Initialize Function --
-------------------------------------------------------------------------------------------------
function AD:Initialize()
	-- Addon Settings Menu
	AD.vars = ZO_SavedVars:NewAccountWide("ADVars", AD.varversion, nil, AD.Settings.DefaultSettings)
	AD.Settings.createSettings()

	AD.Discord.init()
	AD.SOC.init()
	AD.FD.init()

	EVENT_MANAGER:UnregisterForEvent(AD.name, EVENT_ADD_ON_LOADED)
end
 
-------------------------------------------------------------------------------------------------
--  Register Events --
-------------------------------------------------------------------------------------------------
EVENT_MANAGER:RegisterForEvent(AD.name, EVENT_ADD_ON_LOADED, AD.OnAddOnLoaded)