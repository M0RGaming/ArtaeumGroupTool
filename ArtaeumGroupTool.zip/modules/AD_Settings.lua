local AD = ArtaeumGroupTool
local settings = AD.Settings

function settings.createSettings()

	local vars = AD.vars

	local panelName = "ArtaeumGroupToolSettingsPanel"
	local panelData = {
		type = "panel",
		name = "|cFFD700Artaeum Group Tool|r",
		author = "|c0DC1CF@M0R_Gaming|r",
		slashCommand = "/ad"
	}

	local optionsTable = {

		-- STAY ON CROWN MODULE

		{
			type = "header",
			name = "|cFFD700[Stay On Crown Module]|r"
		},
		{
			type = "editbox",
			name = "Time to Kick",
			tooltip = "Time before pugs will be kicked (in minutes).",
			getFunc = function() return vars.SOC.offCrownTimer/60 end,
			setFunc = function(value) AD.SOC.setTimer(value) end,
			isMultiline = false
		},
		{
			type = "editbox",
			name = "Radius",
			tooltip = "If pugs are this much away, the timer will start counting for them. A forward camp radius is 25500 units.",
			getFunc = function() return vars.SOC.radius end,
			setFunc = function(value) vars.SOC.radius = value end,
			isMultiline = false
		},
		{
			type = "editbox",
			name = "Guild ID",
			tooltip = "Enter your whitelist Guild ID in here (-1 for no whitelist)",
			getFunc = function() return vars.SOC.whitelistGuild end,
			setFunc = function(value) vars.SOC.whitelistGuild = value end,
			isMultiline = false
		},
		{
			type = "button",
			name = "Toggle Module",
			tooltip = "Click here to toggle [Stay on Crown].",
			func = function() AD.SOC.startTimer() end
		},
		{
			type = "divider"
		},


		-- DISCORD MODULE


		{
			type = "header",
			name = "|cFFD700[Discord Module]|r"
		},
		{
			type = "editbox",
			name = "Discord Invite Link",
			tooltip = "Please add your discord invite link here.",
			getFunc = function() return vars.Discord.discordLink end,
			setFunc = function(value) vars.Discord.discordLink = value end,
			isMultiline = false	--boolean
		},
		{
			type = "editbox",
			name = "Discord Invite Message",
			tooltip = "Please add your discord invite message here.",
			getFunc = function() return vars.Discord.discordInvite end,
			setFunc = function(value) vars.Discord.discordInvite = value end,
			isMultiline = true	--boolean
		},
		{
			type = "button",
			name = "Send Discord Invite",
			tooltip = "Click here to send a discord invite!",
			func = function() AD.Discord.sendDiscord() end
		},
		{
			type = "divider"
		},


		-- FRONT DOOR MODULE


		{
			type = "header",
			name = "|cFFD700[Front Door Module]|r"
		},
		{
			type = "description",
			title = nil,
			text = "If you wish to disable the pins entirely, use the filter in your map.",
			width = "full",
		},
		{
			type = "checkbox",
			name = "Right Click to Set Rally Marker",
			tooltip = "If this is enabled, you can set your rally marker to the front door of a keep if you right click it.",
			getFunc = function() return vars.FD.rightClickMenu end,
			setFunc = function(value) vars.FD.rightClickMenu = value end
		},



	}


	local panel = LibAddonMenu2:RegisterAddonPanel(panelName, panelData)
	LibAddonMenu2:RegisterOptionControls(panelName, optionsTable)

end